﻿import hashlib
import struct
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from engine.ntfs.filesystem_analysis import apply_usa_fixups, parse_mft_record
from engine.orchestrator.ntfs_recovery_integration import NTFSRecoveryIntegration


def make_record():
    r = bytearray(1024)
    r[:4] = b"FILE"
    struct.pack_into("<HH", r, 4, 48, 3)
    struct.pack_into("<HHHH", r, 16, 1, 1, 64, 1)
    struct.pack_into("<II", r, 24, 140, 1024)

    # Update Sequence Array: USN and the two protected sector trailers.
    r[48:54] = b"\xAA\xBB\x11\x22\x33\x44"
    r[510:512] = b"\xAA\xBB"
    r[1022:1024] = b"\xAA\xBB"

    # Non-resident $DATA attribute, length 72, runlist offset 64.
    p = 64
    struct.pack_into("<I", r, p, 0x80)
    struct.pack_into("<I", r, p + 4, 72)
    r[p + 8] = 1
    r[p + 9] = 0
    struct.pack_into("<HHH", r, p + 10, 0, 0, 1)
    struct.pack_into("<QQH", r, p + 16, 0, 0, 64)
    struct.pack_into("<Q", r, p + 40, 4096)
    struct.pack_into("<Q", r, p + 48, 5)
    struct.pack_into("<Q", r, p + 56, 5)

    # One cluster: length=1, relative LCN delta=8, terminator=0.
    r[p + 64:p + 68] = b"\x11\x01\x08\x00"
    # End-of-attributes marker immediately after the $DATA attribute.
    struct.pack_into("<I", r, p + 72, 0xFFFFFFFF)
    return bytes(r)


def extract_data_runs(fixed_record):
    """Decode a non-resident $DATA runlist from a USA-fixed FILE record."""
    first_attr = struct.unpack_from("<H", fixed_record, 20)[0]
    used_size = struct.unpack_from("<I", fixed_record, 24)[0]
    pos = first_attr

    while pos + 4 <= used_size:
        attr_type = struct.unpack_from("<I", fixed_record, pos)[0]
        if attr_type == 0xFFFFFFFF:
            break
        if attr_type == 0:
            raise AssertionError("Unexpected zero attribute type")
        attr_len = struct.unpack_from("<I", fixed_record, pos + 4)[0]
        if attr_len < 16 or pos + attr_len > used_size:
            raise AssertionError("Invalid MFT attribute bounds")

        if attr_type == 0x80:
            if fixed_record[pos + 8] != 1:
                raise AssertionError("$DATA attribute is not non-resident")
            run_offset = struct.unpack_from("<H", fixed_record, pos + 32)[0]
            real_size = struct.unpack_from("<Q", fixed_record, pos + 48)[0]
            cursor = pos + run_offset
            limit = pos + attr_len
            runs = []
            current_lcn = 0

            while cursor < limit:
                header = fixed_record[cursor]
                cursor += 1
                if header == 0:
                    return runs, real_size

                len_width = header & 0x0F
                off_width = (header >> 4) & 0x0F
                if not len_width or not off_width:
                    raise AssertionError("Invalid runlist field widths")
                if cursor + len_width + off_width > limit:
                    raise AssertionError("Truncated runlist")

                clusters = int.from_bytes(
                    fixed_record[cursor:cursor + len_width], "little"
                )
                cursor += len_width
                delta = int.from_bytes(
                    fixed_record[cursor:cursor + off_width],
                    "little", signed=True
                )
                cursor += off_width
                current_lcn += delta
                runs.append({
                    "lcn": current_lcn,
                    "clusters": clusters,
                    "sparse": False,
                })

            raise AssertionError("Runlist terminator missing")

        pos += attr_len

    raise AssertionError("Non-resident $DATA attribute not found")


class ProfessionalMFTRecoveryTests(unittest.TestCase):
    def test_usa_fixup_and_mft_data_attribute(self):
        raw = make_record()
        fixed = apply_usa_fixups(raw, sector_size=512)
        self.assertEqual(fixed[510:512], b"\x11\x22")
        self.assertEqual(fixed[1022:1024], b"\x33\x44")

        parsed = parse_mft_record(raw, record_number=0, sector_size=512)
        self.assertIsNotNone(parsed)

        runs, size = extract_data_runs(fixed)
        self.assertEqual(size, 5)
        self.assertEqual(runs, [{"lcn": 8, "clusters": 1, "sparse": False}])

    def test_mft_runlist_to_recovery_and_known_sha256(self):
        expected = b"KNOWN"
        known_hash = hashlib.sha256(expected).hexdigest()

        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            image = root / "synthetic_ntfs_layout.img"
            output = root / "recovered.bin"

            data = bytearray(9 * 4096)
            data[4 * 4096:4 * 4096 + 1024] = make_record()
            data[8 * 4096:8 * 4096 + len(expected)] = expected
            image.write_bytes(data)
            source_hash_before = hashlib.sha256(image.read_bytes()).hexdigest()

            # Read precisely one MFT record from its configured location.
            with image.open("rb") as stream:
                stream.seek(4 * 4096)
                raw_record = stream.read(1024)
            self.assertEqual(len(raw_record), 1024)

            parsed = parse_mft_record(raw_record, record_number=0, sector_size=512)
            self.assertIsNotNone(parsed)
            fixed = apply_usa_fixups(raw_record, sector_size=512)
            runs, expected_size = extract_data_runs(fixed)
            self.assertEqual(expected_size, len(expected))

            geometry = SimpleNamespace(
                bytes_per_sector=512,
                cluster_size=4096,
                mft_record_size=1024,
                mft_lcn=4,
            )
            pipeline = NTFSRecoveryIntegration(image, geometry)
            result = pipeline.reconstruct_runs(runs, expected_size, output)

            self.assertTrue(result["passed"], result)
            self.assertEqual(output.read_bytes(), expected)
            self.assertEqual(hashlib.sha256(output.read_bytes()).hexdigest(), known_hash)
            self.assertEqual(
                hashlib.sha256(image.read_bytes()).hexdigest(),
                source_hash_before,
                "Source image changed during recovery",
            )


if __name__ == "__main__":
    unittest.main()
