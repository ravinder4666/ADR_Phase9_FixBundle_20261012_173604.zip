from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
HTML = (ROOT / "ui" / "recovery_dashboard.html").read_text(encoding="utf-8-sig")
JS = (ROOT / "ui" / "recovery_dashboard.js").read_text(encoding="utf-8-sig")
API = (ROOT / "adr_api_server.py").read_text(encoding="utf-8-sig")


class TestPhase8DashboardContract(unittest.TestCase):
    def test_dashboard_uses_real_image_inventory_and_scan_controls(self):
        for token in ('id="imageSelect"', 'id="scanBtn"', 'id="cancelScanBtn"',
                      'id="reportBtn"', 'id="fileRows"'):
            with self.subTest(token=token):
                self.assertIn(token, HTML)

    def test_demo_candidates_and_fake_progress_are_removed(self):
        for token in ("report.pdf", "family_photo.jpg", "sample_drive.E01", "68%"):
            with self.subTest(token=token):
                self.assertNotIn(token, HTML)

    def test_candidate_filters_match_real_validation_states(self):
        self.assertIn('mode === "valid"', JS)
        self.assertIn('mode === "invalid"', JS)
        self.assertIn('mode === "unknown"', JS)
        self.assertIn('validation_code', JS)

    def test_poll_failure_does_not_unlock_scan(self):
        self.assertIn("Scan remains locked until status is confirmed", JS)
        self.assertIn('$("scanBtn").disabled = true', JS)

    def test_recovery_is_not_misrepresented_as_implemented(self):
        self.assertIn('"live_recovery": False', API)
        self.assertIn('"verified_end_to_end_pipeline": False', API)
        self.assertIn("No files were recovered", JS)

    def test_report_button_is_enabled_only_for_completed_jobs(self):
        self.assertIn('$("reportBtn").disabled = job.status !== "COMPLETED"', JS)
        self.assertIn('activeJob.status !== "COMPLETED"', JS)
        self.assertIn('if (activeJob.status !== "COMPLETED")', JS)
        self.assertNotIn('["COMPLETED", "FAILED", "CANCELLED"].includes(activeJob.status)', JS)

    def test_source_hash_is_displayed_when_available(self):
        self.assertIn('id="sourceHashValue"', HTML)
        self.assertIn('job.source_sha256', JS)


if __name__ == "__main__":
    unittest.main()


def test_jobs_endpoint_and_dashboard_restore_latest_job():
    from pathlib import Path

    root = Path(__file__).resolve().parents[1]
    service = (root / "engine" / "orchestrator" /
               "phase7_unified_job_service.py").read_text(encoding="utf-8")
    api = (root / "adr_api_server.py").read_text(encoding="utf-8")
    js = (root / "ui" / "recovery_dashboard.js").read_text(encoding="utf-8")

    assert "def list_jobs(" in service
    assert "PHASE7_JOBS.list_jobs()" in api
    assert 'async function restoreLatestJob()' in js
    assert "await restoreLatestJob();" in js