﻿import hashlib
import io
import json
import tempfile
import unittest
from pathlib import Path

from engine.recovery_validation.deleted_file_recovery import (
    RecoveryError,
    export_recovered_file,
    reconstruct_file_bytes,
    recover_from_runs,
    write_failure_report,
)


class TestDeletedFileRecovery(unittest.TestCase):
    def test_fragmented_runs_reconstruct_in_vcn_order(self):
        # Logical cluster 0 maps to physical cluster 2; cluster 1 maps to 0.
        image = io.BytesIO(b"BBBB" + b"AAAA" + b"")
        result, warnings = reconstruct_file_bytes(
            image, 8,
            [{"vcn_start": 1, "cluster_count": 1, "lcn_start": 0},
             {"vcn_start": 0, "cluster_count": 1, "lcn_start": 1}],
            4, 8
        )
        self.assertEqual(result, b"AAAABBBB")
        self.assertEqual(warnings, [])

    def test_sparse_run_zero_filled_with_warning(self):
        result, warnings = reconstruct_file_bytes(
            io.BytesIO(b"DATA"), 4,
            [{"vcn_start": 0, "cluster_count": 1, "lcn_start": None}],
            4, 4
        )
        self.assertEqual(result, bytes(4))
        self.assertTrue(warnings)

    def test_missing_run_rejected(self):
        with self.assertRaises(RecoveryError):
            reconstruct_file_bytes(
                io.BytesIO(b"x" * 8), 8,
                [{"vcn_start": 1, "cluster_count": 1, "lcn_start": 0}],
                4, 4
            )

    def test_out_of_bounds_run_rejected(self):
        with self.assertRaises(RecoveryError):
            reconstruct_file_bytes(
                io.BytesIO(b"x" * 8), 8,
                [{"vcn_start": 0, "cluster_count": 1, "lcn_start": 2}],
                4, 4
            )

    def test_sha256_and_size_verified_export(self):
        with tempfile.TemporaryDirectory() as td:
            data = b"recovered-test"
            result = export_recovered_file(
                td, "note.txt", data, len(data),
                expected_sha256=hashlib.sha256(data).hexdigest()
            )
            self.assertEqual(result["status"], "RECOVERED_AND_VERIFIED")
            self.assertEqual(Path(result["path"]).read_bytes(), data)
            report = json.loads(Path(result["report_path"]).read_text("utf-8"))
            self.assertEqual(report["sha256"], hashlib.sha256(data).hexdigest())

    def test_existing_output_never_overwritten(self):
        with tempfile.TemporaryDirectory() as td:
            target = Path(td) / "note.txt"
            target.write_bytes(b"original")
            with self.assertRaises(RecoveryError):
                export_recovered_file(td, "note.txt", b"new", 3)
            self.assertEqual(target.read_bytes(), b"original")

    def test_sha256_mismatch_rejected_without_output(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(RecoveryError):
                export_recovered_file(td, "note.txt", b"abc", 3, expected_sha256="0" * 64)
            self.assertFalse((Path(td) / "note.txt").exists())

    def test_traversal_filename_sanitized(self):
        with tempfile.TemporaryDirectory() as td:
            result = export_recovered_file(td, "../../safe.txt", b"x", 1)
            self.assertEqual(Path(result["path"]).parent.resolve(), Path(td).resolve())
            self.assertEqual(Path(result["path"]).name, "safe.txt")

    def test_failure_report_create_only(self):
        with tempfile.TemporaryDirectory() as td:
            result = write_failure_report(td, "job-1", RecoveryError("test failure"))
            self.assertEqual(result["status"], "RECOVERY_FAILED")
            with self.assertRaises(FileExistsError):
                write_failure_report(td, "job-1", RecoveryError("second failure"))


if __name__ == "__main__":
    unittest.main()
