﻿import hashlib
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace

from engine.orchestrator.ntfs_recovery_integration import NTFSRecoveryIntegration


class TestDeletedRecoveryWorkflow(unittest.TestCase):
    def setUp(self):
        self.temp = TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        self.image = self.folder / "synthetic.img"
        # Cluster size = 4. Clusters 1 and 3 hold the two data fragments.
        image = bytearray(64)
        image[4:8] = b"ABCD"
        image[12:16] = b"EFGH"
        self.image.write_bytes(image)
        geometry = SimpleNamespace(
            bytes_per_sector=512, cluster_size=4,
            mft_record_size=1024, mft_lcn=1,
        )
        self.engine = NTFSRecoveryIntegration(self.image, geometry)
        self.metadata = {
            "passed": True,
            "deleted_candidate": True,
            "filenames": [{"name": "fixture.bin"}],
            "data_attributes": [{
                "resident": False,
                "real_size": 8,
                "runs": [
                    {"vcn": 0, "lcn": 1, "clusters": 1, "sparse": False},
                    {"vcn": 1, "lcn": 3, "clusters": 1, "sparse": False},
                ],
            }],
        }
        self.engine.parse_record_at = lambda offset: dict(self.metadata)

    def test_synthetic_fragmented_workflow_and_independent_hash(self):
        output = self.folder / "recovered.bin"
        expected = hashlib.sha256(b"ABCDEFGH").hexdigest()
        result = self.engine.recover_deleted_record(
            1024, output, expected_sha256=expected
        )
        self.assertTrue(result["passed"], result)
        self.assertEqual(result["filename"], "fixture.bin")
        self.assertEqual(output.read_bytes(), b"ABCDEFGH")
        self.assertEqual(hashlib.sha256(output.read_bytes()).hexdigest(), expected)
        self.assertFalse(result["source_modified"])

    def test_wrong_expected_hash_fails_without_creating_output(self):
        output = self.folder / "wrong-hash.bin"
        with self.assertRaisesRegex(ValueError, "expected SHA-256"):
            self.engine.recover_deleted_record(
                1024, output, expected_sha256="0" * 64
            )
        self.assertFalse(output.exists())

    def test_non_candidate_record_is_not_recovered(self):
        self.engine.parse_record_at = lambda offset: {
            "passed": True, "deleted_candidate": False
        }
        result = self.engine.recover_deleted_record(
            1024, self.folder / "blocked.bin"
        )
        self.assertFalse(result["passed"])
        self.assertFalse((self.folder / "blocked.bin").exists())

    def test_resident_data_is_reported_as_not_yet_supported(self):
        self.metadata["data_attributes"][0] = {
            "resident": True, "real_size": 8
        }
        result = self.engine.recover_deleted_record(
            1024, self.folder / "resident.bin"
        )
        self.assertFalse(result["passed"])
        self.assertEqual(result["stage"], "resident_data")

    def test_sparse_and_fragmented_runs_reconstruct_in_order(self):
        output = self.folder / "sparse-fragmented.bin"
        self.metadata["data_attributes"][0] = {
            "resident": False,
            "real_size": 12,
            "runs": [
                {"vcn": 0, "lcn": 1, "clusters": 1, "sparse": False},
                {"vcn": 1, "lcn": None, "clusters": 1, "sparse": True},
                {"vcn": 2, "lcn": 3, "clusters": 1, "sparse": False},
            ],
        }
        result = self.engine.recover_deleted_record(1024, output)
        self.assertTrue(result["passed"], result)
        self.assertEqual(output.read_bytes(), b"ABCD" + b"\x00" * 4 + b"EFGH")


if __name__ == "__main__":
    unittest.main()
