import hashlib
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace

from engine.orchestrator.ntfs_recovery_integration import NTFSRecoveryIntegration


class TestNTFSRecoveryIntegration(unittest.TestCase):
    def geometry(self):
        return SimpleNamespace(
            bytes_per_sector=512,
            cluster_size=4,
            mft_record_size=1024,
            mft_lcn=1,
        )

    def test_rejects_invalid_geometry(self):
        with TemporaryDirectory() as folder:
            image = Path(folder) / "image.img"
            image.write_bytes(b"x" * 4096)
            with self.assertRaises(ValueError):
                NTFSRecoveryIntegration(
                    image, SimpleNamespace(bytes_per_sector=0,
                                           cluster_size=4,
                                           mft_record_size=1024)
                )

    def test_rejects_empty_runlist(self):
        with TemporaryDirectory() as folder:
            image = Path(folder) / "image.img"
            image.write_bytes(b"x" * 4096)
            pipeline = NTFSRecoveryIntegration(image, self.geometry())
            with self.assertRaises(ValueError):
                pipeline.reconstruct_runs([], 4, Path(folder) / "out.bin")

    def test_rejects_existing_output_without_overwriting(self):
        with TemporaryDirectory() as folder:
            image = Path(folder) / "image.img"
            image.write_bytes(b"x" * 4096)
            output = Path(folder) / "out.bin"
            output.write_bytes(b"KEEP")
            pipeline = NTFSRecoveryIntegration(image, self.geometry())
            with self.assertRaises(FileExistsError):
                pipeline.reconstruct_runs(
                    [{"lcn": 1, "clusters": 1, "sparse": False}],
                    4, output
                )
            self.assertEqual(output.read_bytes(), b"KEEP")

    def test_reconstructs_known_cluster_and_hash(self):
        with TemporaryDirectory() as folder:
            image = Path(folder) / "image.img"
            content = b"DATA"
            image.write_bytes(b"\x00" * 4 + content + b"\x00" * 4088)
            output = Path(folder) / "recovered.bin"
            pipeline = NTFSRecoveryIntegration(image, self.geometry())
            result = pipeline.reconstruct_runs(
                [{"lcn": 1, "clusters": 1, "sparse": False}],
                len(content), output
            )
            self.assertTrue(result["passed"], result)
            self.assertEqual(output.read_bytes(), content)
            # Independent fixed SHA-256 for the known fixture bytes b"DATA".
            self.assertEqual(
                result["sha256"],
                "c97c29c7a71b392b437ee03fd17f09bb10b75e879466fc0eb757b2c4a78ac938",
            )
            self.assertEqual(
                hashlib.sha256(output.read_bytes()).hexdigest(),
                "c97c29c7a71b392b437ee03fd17f09bb10b75e879466fc0eb757b2c4a78ac938",
            )
            self.assertEqual(image.read_bytes()[4:8], content)

    def test_sparse_run_is_zero_filled(self):
        with TemporaryDirectory() as folder:
            image = Path(folder) / "image.img"
            image.write_bytes(b"\x00" * 4096)
            output = Path(folder) / "sparse.bin"
            pipeline = NTFSRecoveryIntegration(image, self.geometry())
            result = pipeline.reconstruct_runs(
                [{"lcn": None, "clusters": 1, "sparse": True}],
                4, output
            )
            self.assertTrue(result["passed"], result)
            self.assertEqual(output.read_bytes(), b"\x00" * 4)


if __name__ == "__main__":
    unittest.main()