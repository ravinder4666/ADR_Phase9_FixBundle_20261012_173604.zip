﻿("use strict");
const $ = (id) => document.getElementById(id);
let activeJob = null;
let pollTimer = null;
let candidates = [];

function toast(message) {
  const el = $("toast");
  if (!el) { console.info("[ADR]", message); return; }
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(() => el.classList.remove("show"), 3600);
}
async function requestJSON(url, options = {}) {
  const r = await fetch(url, { cache: "no-store", ...options });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.detail || data.error || `HTTP ${r.status}`);
  return data;
}
function status(message) {
  if ($("scanStatus")) $("scanStatus").textContent = message;
  if ($("adrRecoveryNotice"))
    $("adrRecoveryNotice").textContent =
      message + " Inspection only; no files have been recovered.";
}
function progress(job) {
  const n = Math.max(0, Math.min(100, Number(job.progress) || 0));
  if ($("progressText")) $("progressText").textContent = `${n}% Ã‚Â· ${job.stage || job.status}`;
  if ($("progressFill")) {
    $("progressFill").style.width = `${n}%`;
    $("progressFill").setAttribute("aria-valuenow", String(n));
  }
}
function terminal(s) { return ["COMPLETED", "FAILED", "CANCELLED"].includes(s); }
function updateScanAvailability() {
  const button = $("scanBtn");
  if (!button) return;
  const busy = activeJob && !terminal(activeJob.status);
  const selected = Boolean($("imageSelect")?.value);
  button.disabled = Boolean(busy) || !selected;
}
function renderCandidates() {
  const body = $("fileRows");
  if (!body) return;
  body.replaceChildren();
  const term = ($("searchInput")?.value || "").trim().toLowerCase();
  const mode = $("typeFilter")?.value || "all";
  const filtered = candidates.filter(c => {
    const haystack = [
      c.offset, c.record_number, c.sequence_number, c.validation_code,
      c.validation_engine, c.validation_error, c.header_valid
    ].map(v => v == null ? "" : String(v)).join(" ").toLowerCase();
    const matchesSearch = !term || haystack.includes(term);
    const matchesMode = mode === "all"
      || (mode === "valid" && c.header_valid === true)
      || (mode === "invalid" && c.header_valid === false)
      || (mode === "unknown" && c.header_valid !== true && c.header_valid !== false);
    return matchesSearch && matchesMode;
  });
  for (const c of filtered) {
    const tr = document.createElement("tr");
    const label = `MFT candidate Ã‚Â· offset ${c.offset ?? "unknown"}`;
    const valid = c.header_valid === true;
    const invalid = c.header_valid === false;
    const cells = [
      label,
      "NTFS/MFT",
      c.record_size == null ? "Unknown" : `${c.record_size} bytes`,
      valid ? "Structural check passed" : (invalid ? "Invalid header" : "Unverifiable"),
      "Not recovered",
      ""
    ];
    for (const value of cells) {
      const td = document.createElement("td");
      td.textContent = String(value);
      tr.appendChild(td);
    }
    body.appendChild(tr);
  }
  if (!filtered.length) {
    const tr = document.createElement("tr");
    const td = document.createElement("td");
    td.colSpan = 6;
    td.textContent = candidates.length ? "No matching candidates." : "No scan candidates yet.";
    tr.appendChild(td);
    body.appendChild(tr);
  }
  if ($("candidateCount")) $("candidateCount").textContent = String(candidates.length);
  if ($("validatedCount"))
    $("validatedCount").textContent = String(candidates.filter(c => c.header_valid === true).length);
  if ($("resultCount")) $("resultCount").textContent = `${filtered.length} candidate(s)`;
}
async function loadImages() {
  const select = $("imageSelect");
  if (!select) return;
  try {
    const data = await requestJSON("/api/images");
    select.replaceChildren();
    select.add(new Option("Select a disk image...", ""));
    for (const img of data.images || [])
      select.add(new Option(`${img.name} (${img.size_bytes.toLocaleString()} bytes)`, img.name));
    if (!(data.images || []).length) {
      select.replaceChildren(new Option("No non-empty files in test_images", ""));
      status("No scan image available in test_images.");
    } else {
      status("Ready. Select an image for read-only NTFS inspection.");
    }
    updateScanAvailability();
  } catch (e) {
    select.replaceChildren(new Option("Image list unavailable", ""));
    $("scanBtn").disabled = true;
    status("Image inventory failed: " + e.message);
  }
}
function applyJob(job) {
  activeJob = job;
  if ($("evidenceSourceName") && job.source_name)
    $("evidenceSourceName").textContent = job.source_name;
  if ($("sourceHashValue")) {
    $("sourceHashValue").textContent = job.source_sha256 || "Hash pending";
    $("sourceHashValue").title = job.source_sha256 || "";
  }
  progress(job);
  status(`${job.status} Ã‚Â· ${job.stage || "scan"} Ã‚Â· ${job.progress || 0}%`);
  const result = job.result || {};
  candidates = Array.isArray(result.candidates) ? result.candidates : [];
  renderCandidates();
  const finished = terminal(job.status);
  if ($("cancelScanBtn")) $("cancelScanBtn").disabled = finished;
  updateScanAvailability();
  // The API serves reports only for COMPLETED jobs; FAILED/CANCELLED are not reportable.
  if ($("reportBtn")) $("reportBtn").disabled = job.status !== "COMPLETED";
  if (finished) {
    clearTimeout(pollTimer);
    if (job.status === "COMPLETED") toast("Scan finished. No files were recovered.");
    else if (job.status === "FAILED") {
      const detail = typeof job.error === "string" ? job.error
        : (job.error && (job.error.message || job.error.type)) || "Unknown scan error";
      toast("Scan failed: " + detail);
    }
    else toast("Scan cancelled.");
  }
}
async function pollJob(id) {
  try {
    const data = await requestJSON(`/api/jobs/${encodeURIComponent(id)}`);
    applyJob(data.job);
    if (!terminal(data.job.status)) pollTimer = setTimeout(() => pollJob(id), 900);
  } catch (e) {
    status("Job status temporarily unavailable: " + e.message + ". Scan remains locked until status is confirmed.");
    if ($("scanBtn")) $("scanBtn").disabled = true;
    if ($("cancelScanBtn")) $("cancelScanBtn").disabled = false;
    pollTimer = setTimeout(() => pollJob(id), 2000);
  }
}
async function restoreLatestJob() {
  try {
    const data = await requestJSON("/api/jobs");
    const jobs = Array.isArray(data.jobs) ? data.jobs : [];
    if (jobs.length > 0) {
      applyJob(jobs[0]);
    }
  } catch (error) {
    console.warn("Could not restore the latest recovery job:", error);
  }
}

async function startScan() {
  const image = $("imageSelect")?.value;
  if (!image) { toast("Please select an image first."); return; }
  if (activeJob && !terminal(activeJob.status)) return;
  if (pollTimer) clearTimeout(pollTimer);
  $("scanBtn").disabled = true;
  $("reportBtn").disabled = true;
  $("cancelScanBtn").disabled = false;
  candidates = []; renderCandidates();
  status("Submitting scan...");
  try {
    const data = await requestJSON("/api/scans", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ image, max_records: Number($("maxRecords").value) })
    });
    applyJob(data.job);
    if (!terminal(data.job.status)) pollJob(data.job.job_id);
  } catch (e) {
    if ($("cancelScanBtn")) $("cancelScanBtn").disabled = true;
    activeJob = null;
    updateScanAvailability();
    status("Scan request rejected: " + e.message);
    toast("Scan could not start: " + e.message);
  }
}
async function cancelScan() {
  if (!activeJob?.job_id) return;
  $("cancelScanBtn").disabled = true;
  try {
    const data = await requestJSON(
      `/api/jobs/${encodeURIComponent(activeJob.job_id)}/cancel`,
      { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" }
    );
    applyJob(data.job);
    if (!terminal(data.job.status)) pollJob(data.job.job_id);
  } catch (e) { toast("Cancellation failed: " + e.message); }
}
async function downloadReport() {
  if (!activeJob?.job_id) {
    toast("Start a scan before downloading its report.");
    return;
  }
  if (activeJob.status !== "COMPLETED") {
    toast("Report is available only after a completed scan.");
    return;
  }
  const button = $("reportBtn");
  if (button) button.disabled = true;
  try {
    const report = await requestJSON(
      `/api/jobs/${encodeURIComponent(activeJob.job_id)}/report`
    );
    const blob = new Blob([JSON.stringify(report, null, 2)], {
      type: "application/json"
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `adr_scan_${activeJob.job_id}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast("API scan report downloaded.");
  } catch (e) {
    toast("Report download failed: " + e.message);
  } finally {
    if (button) button.disabled = !activeJob || activeJob.status !== "COMPLETED";
  }
}

function adrEscape(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
  })[ch]);
}
function adrStorageRead(key) {
  try {
    const value = JSON.parse(localStorage.getItem(key) || "[]");
    return Array.isArray(value) ? value : [];
  } catch (_) { return []; }
}
function adrStorageWrite(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); return true; }
  catch (_) { toast("Browser storage unavailable or full."); return false; }
}
function adrViewRoot() {
  let root = $("adrSecondaryView");
  if (!root) {
    root = document.createElement("section");
    root.id = "adrSecondaryView";
    root.className = "panel adr-secondary-view";
    root.setAttribute("aria-live", "polite");
    const content = document.querySelector(".content");
    const heading = document.querySelector(".page-heading");
    if (!content || !heading) throw new Error("Dashboard content container is missing.");
    heading.insertAdjacentElement("afterend", root);
  }
  return root;
}
function adrImageOptions() {
  const source = $("imageSelect");
  if (!source) return '<option value="">Image selector unavailable</option>';
  return Array.from(source.options).map(o =>
    `<option value="${adrEscape(o.value)}">${adrEscape(o.textContent)}</option>`
  ).join("");
}
function adrCaseMarkup() {
  const cases = adrStorageRead("adr.dashboard.cases.v1");
  const rows = cases.map(c => `<tr><td>${adrEscape(c.id)}</td><td>${adrEscape(c.title)}</td><td>${adrEscape(c.created)}</td><td>${adrEscape(c.notes || "")}</td></tr>`).join("");
  return `
    <div class="adr-view-heading"><div><h2>Case Management</h2><p>Create and track local workspace cases.</p></div></div>
    <p class="adr-warning">Case records are stored in this browser only. This is not a tamper-proof forensic case database.</p>
    <form id="adrCaseForm" class="adr-form">
      <label>Case title<input name="title" maxlength="120" required placeholder="e.g. Case 2026-001"></label>
      <label>Case notes<textarea name="notes" maxlength="2000" rows="3" placeholder="Purpose and case notes"></textarea></label>
      <button class="btn primary" type="submit">Create case</button>
    </form>
    <h3>Local cases (${cases.length})</h3>
    <div class="table-wrap"><table><thead><tr><th>Case ID</th><th>Title</th><th>Created</th><th>Notes</th></tr></thead><tbody>${rows || '<tr><td colspan="4">No cases created in this browser.</td></tr>'}</tbody></table></div>`;
}
function adrEvidenceMarkup() {
  const items = adrStorageRead("adr.dashboard.evidence.v1");
  const rows = items.map(e => `<tr><td>${adrEscape(e.name)}</td><td>${adrEscape(e.size)}</td><td><code>${adrEscape(e.sha256)}</code></td><td>${adrEscape(e.checked)}</td></tr>`).join("");
  return `
    <div class="adr-view-heading"><div><h2>Evidence &amp; Hashes</h2><p>Read-only SHA-256 inspection of a test image.</p></div></div>
    <p class="adr-warning">Browser-stored entries are not a protected chain of custody. Preserve original evidence and independently document custody.</p>
    <form id="adrEvidenceForm" class="adr-form">
      <label>Image<select name="image" required>${adrImageOptions()}</select></label>
      <button class="btn primary" type="submit">Calculate / verify SHA-256</button>
    </form>
    <div id="adrEvidenceResult" role="status"></div>
    <h3>Browser evidence register (${items.length})</h3>
    <div class="table-wrap"><table><thead><tr><th>Image</th><th>Size</th><th>SHA-256</th><th>Checked</th></tr></thead><tbody>${rows || '<tr><td colspan="4">No evidence inspections recorded.</td></tr>'}</tbody></table></div>`;
}
function adrImagingMarkup() {
  return `
    <div class="adr-view-heading"><div><h2>Disk Imaging</h2><p>Inspect supported image files without modifying the source.</p></div></div>
    <p class="adr-warning">This dashboard currently offers image metadata/hash inspection, not a complete physical-disk acquisition workflow. No physical disk imaging is claimed.</p>
    <form id="adrImagingForm" class="adr-form">
      <label>Existing test image<select name="image" required>${adrImageOptions()}</select></label>
      <button class="btn primary" type="submit">Inspect image and calculate hash</button>
    </form>
    <div id="adrImagingResult" role="status"></div>`;
}
function adrRecoverMarkup() {
  return `
    <div class="adr-view-heading">
      <div>
        <h2>Recover Files</h2>
        <p>Recover a supported deleted NTFS/MFT candidate from an image in the test-image inventory.</p>
      </div>
    </div>
    <div class="adr-warning">
      <strong>Scope and verification:</strong>
      This form supports only images exposed by the existing test-image inventory.
      Enter geometry and record offset from trusted inspection. A matching output hash
      proves a match only when the expected original SHA-256 is independently known.
      This is not a physical-disk recovery workflow.
    </div>
    <form id="adrRecoverForm" class="adr-form">
      <label>Source image
        <select name="image" required>${adrImageOptions()}</select>
      </label>
      <label>MFT record offset (bytes)
        <input name="record_offset" type="number" min="0" step="1" required>
      </label>
      <label>Bytes per sector
        <input name="bytes_per_sector" type="number" min="1" step="1" required>
      </label>
      <label>Cluster size (bytes)
        <input name="cluster_size" type="number" min="1" step="1" required>
      </label>
      <label>MFT record size (bytes)
        <input name="mft_record_size" type="number" min="1" step="1" required>
      </label>
      <label>MFT starting cluster (LCN)
        <input name="mft_lcn" type="number" min="0" step="1" required>
      </label>
      <label>Partition offset (bytes, if applicable)
        <input name="partition_offset" type="number" min="0" step="1">
      </label>
      <label>New destination filename
        <input name="destination" type="text" maxlength="180"
          pattern="[^\\\\/:*?&quot;&lt;&gt;|]+" required>
      </label>
      <label>Known original SHA-256 (optional)
        <input name="expected_sha256" type="text" minlength="64" maxlength="64"
          pattern="[A-Fa-f0-9]{64}" placeholder="64 hexadecimal characters">
      </label>
      <button class="btn primary" type="submit">Recover and verify output</button>
    </form>
    <div id="adrRecoveryResult" role="status" aria-live="polite"></div>
    <p class="adr-warning">Recovery writes to the backend's separate recovered_files directory.
      Existing destination files are not overwritten. Use a disposable test image first.</p>`;
}
async function adrReportsMarkup() {
  const root = adrViewRoot();
  root.innerHTML = '<h2>Reports</h2><p>Loading job history...</p>';
  try {
    const data = await requestJSON("/api/jobs");
    const jobs = Array.isArray(data.jobs) ? data.jobs : [];
    const rows = jobs.map(j => `<tr>
      <td><code>${adrEscape(j.job_id)}</code></td><td>${adrEscape(j.source_name)}</td>
      <td>${adrEscape(j.status)}</td><td>${adrEscape(j.progress)}%</td>
      <td>${j.status === "COMPLETED" ? `<button class="btn secondary" data-adr-report="${adrEscape(j.job_id)}">Download JSON</button>` : "Not available"}</td>
    </tr>`).join("");
    root.innerHTML = `<h2>Reports &amp; Job History</h2><p>Reports are available only for completed scans.</p>
      <div class="table-wrap"><table><thead><tr><th>Job</th><th>Source</th><th>Status</th><th>Progress</th><th>Report</th></tr></thead>
      <tbody>${rows || '<tr><td colspan="5">No scan jobs recorded in this server session.</td></tr>'}</tbody></table></div>`;
  } catch (e) {
    root.innerHTML = `<h2>Reports</h2><p class="adr-error">Could not load reports: ${adrEscape(e.message)}</p>`;
  }
}
function adrSettingsMarkup() {
  return `<div class="adr-view-heading"><div><h2>Settings &amp; Backend Status</h2><p>Live service capabilities reported by the API.</p></div></div>
    <button class="btn secondary" id="adrRefreshHealth">Refresh backend status</button><div id="adrSettingsResult" role="status">Not checked yet.</div>
    <p class="adr-warning">Unsupported capabilities must remain disabled until their implementation and tests are complete.</p>`;
}
async function adrInspectImage(image, targetId) {
  const target = $(targetId);
  if (target) target.textContent = "Inspecting image read-only; calculating SHA-256...";
  try {
    const data = await requestJSON("/api/image/inspect", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({image})
    });
    const item = data.inspection || data.image || {};
    if (target) target.innerHTML =
      `<p><strong>${adrEscape(item.name || image)}</strong></p>
       <p>Size: ${adrEscape(item.size)} bytes</p>
       <p>SHA-256: <code>${adrEscape(item.sha256)}</code></p>
       <p>Source modified: ${item.source_modified === false ? "No (API-reported)" : "Not independently verified"}</p>
       <p>Recoverability proven: No</p>`;
    return item;
  } catch (e) {
    if (target) target.innerHTML = `<p class="adr-error">Inspection failed: ${adrEscape(e.message)}</p>`;
    throw e;
  }
}
async function adrDownloadJobReport(id) {
  try {
    const data = await requestJSON(`/api/jobs/${encodeURIComponent(id)}/report`);
    const blob = new Blob([JSON.stringify(data.report || data, null, 2)], {type:"application/json"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `adr_scan_${id}.json`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast("Completed scan report downloaded.");
  } catch (e) { toast("Report download failed: " + e.message); }
}
async function adrShowView(view) {
  const root = adrViewRoot();
  const heading = document.querySelector(".page-heading");
  const notice = document.querySelector(".content > .notice");
  const stats = document.querySelector(".content > .stats");
  const workGrid = document.querySelector(".content > .work-grid");
  const results = document.querySelector(".content > .results-panel");
  const footer = document.querySelector(".content > footer");
  const dashboard = view === "Dashboard";
  if (heading) heading.hidden = !dashboard;
  if (notice) notice.hidden = !dashboard;
  if (stats) stats.hidden = !dashboard;
  if (workGrid) workGrid.hidden = !dashboard;
  if (footer) footer.hidden = !dashboard;
  if (results) results.hidden = !(dashboard || view === "Scan Results");
  root.hidden = dashboard || view === "Scan Results";
  if ($("crumbPage")) $("crumbPage").textContent = view;
  if ($("pageTitle")) $("pageTitle").textContent = view === "Dashboard" ? "Recovery Workspace" : view;
  if (dashboard || view === "Scan Results") return;

  root.innerHTML = "";
  if (view === "Create Case") root.innerHTML = adrCaseMarkup();
  else if (view === "Recover Files") root.innerHTML = adrRecoverMarkup();
  else if (view === "Disk Imaging") root.innerHTML = adrImagingMarkup();
  else if (view === "Evidence & Hashes") root.innerHTML = adrEvidenceMarkup();
  else if (view === "Reports") { await adrReportsMarkup(); return; }
  else if (view === "Settings") root.innerHTML = adrSettingsMarkup();
  else root.innerHTML = `<h2>${adrEscape(view)}</h2><p>This section has no configured workflow.</p>`;
}
document.querySelectorAll(".nav-item[data-view]").forEach(button => {
  button.addEventListener("click", async () => {
    document.querySelectorAll(".nav-item[data-view]").forEach(item => item.classList.remove("active"));
    button.classList.add("active");
    try { await adrShowView(button.dataset.view); }
    catch (e) { toast("Could not open section: " + e.message); }
  });
});
document.addEventListener("submit", async event => {
  const form = event.target;
  if (!(form instanceof HTMLFormElement)) return;
  if (form.id === "adrRecoverForm") {
    event.preventDefault();
    const fd = new FormData(form);
    const target = $("adrRecoveryResult");
    const integerField = (name) => {
      const raw = String(fd.get(name) ?? "").trim();
      if (!/^\d+$/.test(raw)) throw new Error("Invalid integer: " + name);
      const value = Number(raw);
      if (!Number.isSafeInteger(value)) throw new Error("Value is out of range: " + name);
      return value;
    };
    let payload;
    try {
      payload = {
        image: String(fd.get("image") || "").trim(),
        record_offset: integerField("record_offset"),
        geometry: {
          bytes_per_sector: integerField("bytes_per_sector"),
          cluster_size: integerField("cluster_size"),
          mft_record_size: integerField("mft_record_size"),
          mft_lcn: integerField("mft_lcn")
        },
        destination: String(fd.get("destination") || "").trim()
      };
      const partitionOffset = String(fd.get("partition_offset") || "").trim();
      if (partitionOffset !== "") {
        if (!/^\d+$/.test(partitionOffset) || !Number.isSafeInteger(Number(partitionOffset)))
          throw new Error("Invalid partition offset.");
        payload.geometry.partition_offset = Number(partitionOffset);
      }
      const expected = String(fd.get("expected_sha256") || "").trim();
      if (expected) {
        if (!/^[a-fA-F0-9]{64}$/.test(expected))
          throw new Error("Expected SHA-256 must contain exactly 64 hexadecimal characters.");
        payload.expected_sha256 = expected;
      }
      if (!payload.image || !payload.destination)
        throw new Error("Select an image and enter a destination filename.");
      if (/[\\\\/:*?"<>|]/.test(payload.destination) ||
          payload.destination === "." || payload.destination === "..")
        throw new Error("Destination must be a plain filename, not a path.");
    } catch (e) {
      if (target) target.textContent = "Recovery not started: " + e.message;
      return;
    }

    const submit = form.querySelector('button[type="submit"]');
    if (submit) submit.disabled = true;
    if (target) target.textContent = "Recovery request running; checking output and source integrity...";
    try {
      const envelope = await requestJSON("/api/recoveries", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(payload)
      });
      const result = envelope.recovery || {};
      const lines = [
        "API request: accepted",
        "Recovery status: " + String(result.status || "UNKNOWN"),
        "Source unchanged: " + String(result.source_unchanged),
        "Known-original hash verified: " + String(result.known_original_hash_verified),
        "Output path: " + String(result.output_path || "not provided"),
        "Output size: " + String(result.output_size ?? "unknown"),
        "Output SHA-256: " + String(result.output_sha256 || "not provided"),
        "Source SHA-256 before: " + String(result.source_sha256_before || "not provided"),
        "Source SHA-256 after: " + String(result.source_sha256_after || "not provided")
      ];
      if (Array.isArray(result.limitations) && result.limitations.length) {
        lines.push("Limitations:");
        for (const item of result.limitations) lines.push("- " + String(item));
      }
      if (target) target.textContent = lines.join("\n");
      toast(result.status === "VERIFIED_OUTPUT"
        ? (result.known_original_hash_verified
            ? "Output verified against the supplied known-original hash."
            : "Output checks passed; original-file identity is not proven.")
        : "Recovery output is NOT VERIFIED.");
    } catch (e) {
      if (target) target.textContent = "Recovery request failed: " + e.message;
      toast("Recovery failed: " + e.message);
    } finally {
      if (submit) submit.disabled = false;
    }
  } else if (form.id === "adrCaseForm") {
    event.preventDefault();
    const fd = new FormData(form);
    const title = String(fd.get("title") || "").trim();
    const notes = String(fd.get("notes") || "").trim();
    if (!title) { toast("Case title is required."); return; }
    const cases = adrStorageRead("adr.dashboard.cases.v1");
    cases.unshift({
      id: "ADR-" + new Date().toISOString().replace(/\D/g, "").slice(0,14),
      title, notes, created: new Date().toLocaleString()
    });
    if (adrStorageWrite("adr.dashboard.cases.v1", cases)) {
      await adrShowView("Create Case"); toast("Case saved in this browser.");
    }
  } else if (form.id === "adrEvidenceForm") {
    event.preventDefault();
    const image = String(new FormData(form).get("image") || "");
    if (!image) { toast("Select an image first."); return; }
    try {
      const item = await adrInspectImage(image, "adrEvidenceResult");
      const entries = adrStorageRead("adr.dashboard.evidence.v1");
      entries.unshift({name:item.name || image, size:item.size, sha256:item.sha256, checked:new Date().toLocaleString()});
      if (adrStorageWrite("adr.dashboard.evidence.v1", entries)) {
        await adrShowView("Evidence & Hashes");
        const target = $("adrEvidenceResult");
        if (target) target.textContent = "Inspection recorded in browser storage. Hash: " + item.sha256;
      }
    } catch (_) {}
  } else if (form.id === "adrImagingForm") {
    event.preventDefault();
    const image = String(new FormData(form).get("image") || "");
    if (image) try { await adrInspectImage(image, "adrImagingResult"); } catch (_) {}
  }
});
document.addEventListener("click", async event => {
  const reportButton = event.target.closest("[data-adr-report]");
  if (reportButton) await adrDownloadJobReport(reportButton.dataset.adrReport);
  if (event.target.closest("#adrRefreshHealth")) {
    const target = $("adrSettingsResult");
    if (target) target.textContent = "Checking...";
    try {
      const [health, caps] = await Promise.all([
        requestJSON("/api/health"), requestJSON("/api/capabilities")
      ]);
      if (target) target.textContent = JSON.stringify({
        health: health.status,
        capabilities: caps.capabilities
      }, null, 2);
    } catch (e) {
      if (target) target.textContent = "Backend check failed: " + e.message;
    }
  }
});
document.querySelectorAll("[data-go]").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelector(`.nav-item[data-view="${button.dataset.go}"]`)?.click();
  });
});
document.addEventListener("DOMContentLoaded", async () => {
  new Set([$("scanBtn"), $("startScan"), $("startScanBtn")].filter(Boolean))
    .forEach(button => button.addEventListener("click", startScan));
  $("reportBtn")?.addEventListener("click", downloadReport);
  $("cancelScanBtn")?.addEventListener("click", cancelScan);
  $("imageSelect")?.addEventListener("change", updateScanAvailability);
  $("searchInput")?.addEventListener("input", renderCandidates);
  $("typeFilter")?.addEventListener("change", renderCandidates);
  if ($("reportBtn")) $("reportBtn").disabled = true;
  if ($("cancelScanBtn")) $("cancelScanBtn").disabled = true;
  updateScanAvailability();
  renderCandidates();
  await loadImages();
  await restoreLatestJob();
  try {
    const [health, caps] = await Promise.all([
      requestJSON("/api/health"), requestJSON("/api/capabilities")
    ]);
    if ($("adrApiHealth")) $("adrApiHealth").textContent = health.ok ? "Connected" : "Unhealthy";
    if ($("adrApiCapabilities")) {
      const c = caps.capabilities || {};
      $("adrApiCapabilities").textContent =
        `Read-only scan: ${c.live_scan ? "enabled" : "disabled"} | Recovery: ${c.live_recovery ? "enabled" : "disabled"}`;
    }
  } catch (_) {
    if ($("adrApiHealth")) $("adrApiHealth").textContent = "Disconnected";
  }
});


